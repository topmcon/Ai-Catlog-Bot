import { createRoot } from 'react-dom/client'
import PartsApp from './PartsApp.jsx'
import './index.css'

createRoot(document.getElementById('root')).render(<PartsApp />)
